Example dataset from Recla et al. (2014) and Logan et al. (2013)
 See https://github.com/kbroman/qtl2data/tree/master/DO_Recla
 
 Contents (each with initial ID column):
 kinship.csv: kinship matrix
 pheno.csv:   phenotypes
 covar.csv:   sex covariate
